mw.loader.state({"skins.cppreference2":"ready"});
/* cache key: mwiki1-mwiki_en_:resourceloader:filter:minify-js:7:728f164a1dd8ee369e4d25e8cde66537 */
/* Cached 20190605201000 */